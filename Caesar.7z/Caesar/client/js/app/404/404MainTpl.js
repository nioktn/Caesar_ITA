templates.ErrorPageMainTpl = _.template([
	'<div class="modal-body">',
		'<div class="message-body">',
		    '<p>404</p>',
	   	'</div>',
	'</div>'
].join(''));