templates.groupScheduleViewTpl = ([
	'<div class="week-wrapper">',
	'</div>',
	'<div class="key-dates-wrapper">',
	'</div>'
].join(''));
