templates.activityTpl = _.template([
    '<p> <%= title %> <br> <%= teacher %> <br> <%= room %> </p>'
].join(''));