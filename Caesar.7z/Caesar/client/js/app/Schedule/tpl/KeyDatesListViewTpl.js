templates.keyDatesListViewTpl = _.template([
    '<thead>',
        '<tr>',
            '<th>Group</th>',
            '<th>Start</th>',
            '<th>Demo1</th>',
            '<th>Demo2</th>',
            '<th>Offering</th>',
            '<th>Finish</th>',
        '</tr>',
    '</thead>',
    '<tbody>',
    '</tbody>'
].join(''));