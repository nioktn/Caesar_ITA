templates.oneGroupTpl = _.template([
    '<p>',
        '<%= name %>',
    '</p>'
].join(''));