templates.activityEditorTpl = _.template([
    '<p> <%= title %> <br> <%= teacher %> <br> <%= room %> </p>'
].join(''));