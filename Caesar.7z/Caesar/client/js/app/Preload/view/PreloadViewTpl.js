'use strict';

templates.preloadView = _.template([
    '<div class="wrapper-preload">',
        '<i class="demo-icon icon-spin6 animate-spin">&#xe800;</i>',
    '</div>'
].join(''));
