templates.attachmentsListViewTpl = _.template([
    '<div class="student_attachments-wrapper">',
        '<div>',
            '<ul>',
            '</ul>',
            '<div class="student_attachments-buttons">',
                '<button class="cancel">',
                    '<i class="fa fa-times-circle-o fa-3x"></i>',
                '</button>',
            '</div>',
        '</div>',
    '</div>'
].join(''));