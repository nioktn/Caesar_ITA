templates.locationViewTpl = _.template([
    '<p>',
        '<%= name %>',
    '</p>'
].join(''));