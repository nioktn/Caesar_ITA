templates.hintTpl = _.template([
		    '<p class="hint"> <%=text%></p>',
		    '<div class="hintTriangle"></div>'
].join(''));