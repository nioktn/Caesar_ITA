'use strict';

(function (This) {
    This.Menu = Backbone.Collection.extend({
        model: This.ItemMenu
    });
})(CS.Menu);
