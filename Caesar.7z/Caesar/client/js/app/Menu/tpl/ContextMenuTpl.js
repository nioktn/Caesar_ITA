'use strict';

templates.ContextMenuTpl = _.template([
    '<div class="contextMenu">',
    '</div>'
].join(''));
