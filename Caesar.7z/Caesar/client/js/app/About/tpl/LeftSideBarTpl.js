templates.leftSideBarTpl = _.template([
	'<div class="javascript menuAbout"><p>Development & Research</p></div>',
	'<div class="mqc menuAbout"><p>Quality Assurance</p></div>',
	'<div class="softserve menuAbout"><p>Management and Mentoring</p></div>',
	'<div class="other menuAbout"><p>Additional Thanks</p></div>'	
].join(''));