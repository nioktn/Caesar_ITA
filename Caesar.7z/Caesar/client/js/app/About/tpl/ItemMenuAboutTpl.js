templates.ItemMenuAboutTpl = _.template([
	'<div class="menuAbout"><p><%= direction %></p></div>'
].join(''));