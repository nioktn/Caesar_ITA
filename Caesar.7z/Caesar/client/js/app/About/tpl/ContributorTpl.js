templates.ContributorTpl = _.template([	
	'<div class="contributorPhoto"><img src="<%= photo %>" alt="photo" class="img-circle"></div>'	
].join(''));