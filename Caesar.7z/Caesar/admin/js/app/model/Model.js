'use strict';
(function (This) {
    This.Model = Backbone.Model.extend({

    });
})(CSAdmin);